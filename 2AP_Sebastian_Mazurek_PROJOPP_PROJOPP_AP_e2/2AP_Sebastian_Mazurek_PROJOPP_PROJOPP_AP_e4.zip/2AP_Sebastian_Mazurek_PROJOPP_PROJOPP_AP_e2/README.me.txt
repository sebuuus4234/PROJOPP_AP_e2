1.Wersja -Ver 0.00 wczesna (Alpha)

2.Cel -Obliczanie funkcji matematycznych

3.jak działa? -Jak kalkulator (rozwiązuje zadania matematyczne)

4.Zasada działania interakcji z użytkownikiem -Wprowadzenie danych do aplikacji (kalkulatora) -Użytkownik może wprowadzać dane za pomocą klawiatury, myszy lub dotykowego ekranu

5.Aktualizacje- zastosowałem 5 różnych zasad clean code oraz rozbudowałem kod. 